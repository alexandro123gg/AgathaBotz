/*
• Base Ori GhostXmods X WannOFFC
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Ghost [ Develover Sc ]  
- WannOFFC [ Support ]
- Pengguna Bot Yang Selalu Support

• Recode By ( Denzx Official )
*/

require("./WannOFFC")
