/*
• Base Ori GhostXmods X WannOFFC
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Ghost [ Develover Sc ]  
- WannOFFC [ Support ]
- Pengguna Bot Yang Selalu Support

• Recode By ( ARTA )
*/

const settings = {
  token: '7101214526:AAFA-tl3efJbAkB9-MVK8sIbQJeJwUQNvbA', // Token Bot
  adminId: '6042924701',
  urladmin: 'https://t.me/JustARTAA1',
  pp: 'https://telegra.ph/file/1d6c69d5ae1cd5bd862cc.jpg',
    //SERVER 1
  domain: 'https://ahmadfauzi.panelprivv.xyz', // Isi dengan domain yang digunakan
  plta: 'ptla_lPoWVONI7TdYAJD88pe9e6mNEVmnclwhis1BW3VuoQ1', // Isi dengan nilai plta yang sesuai
  pltc: 'ptlc_TbxpWbdzlgjZrYsLJigph1mTe8ArZWdnX2zpgfcXHPQ', // Isi dengan nilai pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;